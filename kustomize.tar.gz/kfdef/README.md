This directory contains YAML files defining resources.

These YAMl files can be used in conjuction with kfctl to deploy Kubeflow.
