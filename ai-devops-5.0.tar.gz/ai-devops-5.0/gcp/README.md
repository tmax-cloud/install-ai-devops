.
==================================================

# NAME

  .

# SYNOPSIS

  kubectl apply --recursive -f .

# Description

GCP blueprint configs.

# SEE ALSO

